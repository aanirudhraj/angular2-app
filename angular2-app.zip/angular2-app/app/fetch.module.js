"use strict";
var fetch = (function () {
    function fetch() {
    }
    return fetch;
}());
exports.fetch = fetch;
//# sourceMappingURL=fetch.module.js.map