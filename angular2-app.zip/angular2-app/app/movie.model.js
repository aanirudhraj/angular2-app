"use strict";
var Movie = (function () {
    function Movie() {
    }
    return Movie;
}());
exports.Movie = Movie;
//# sourceMappingURL=movie.model.js.map