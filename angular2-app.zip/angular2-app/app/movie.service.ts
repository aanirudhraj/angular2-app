import { Injectable } from '@angular/core';  
import { Headers, Http } from '@angular/http';  
import { Movie } from './movie.model';
import { fetch } from './fetch.module';


import 'rxjs/add/operator/toPromise';


@Injectable()
export class MovieService {  
  private endUrl : string = ""



  constructor(private http: Http) { }


   getList(search:any): Promise<fetch> {
   return this.http.get(this.endUrl + search )
      .toPromise()
      .then(response =>
        response
          .json().console(response.json.toString()) as fetch)
          .catch(this.handleError); 
        
  }


  private handleError(error: any): Promise<any> {
    console.error('**ERROR**', error);
    return Promise.reject(error.message || error);
  }
}